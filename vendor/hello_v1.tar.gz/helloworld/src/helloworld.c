#include <stdio.h>

int main(void) {
    puts("hello");
}

